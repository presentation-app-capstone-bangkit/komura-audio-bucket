# test_import.py
from werkzeug.utils import secure_filename
print("Import berhasil!")
