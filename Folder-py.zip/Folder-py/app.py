from flask import Flask, request, jsonify
from google.cloud import storage
import os

app = Flask(__name__)

# Set GOOGLE_APPLICATION_CREDENTIALS environment variable
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "komura-app-9ca8e-926b55950373.json"

@app.route('/process-audio', methods=['POST'])
def process_audio():
    if 'file' not in request.files:
        return jsonify({'message': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'message': 'No selected file'}), 400

    # Upload ke GCS
    try:
        client = storage.Client()
        bucket = client.get_bucket('komura-audio-bucket')  # Nama bucket yang benar
        blob = bucket.blob(file.filename)
        blob.upload_from_file(file, content_type=file.content_type)

        # URL publik file audio di GCS
        audio_url = blob.public_url

        return jsonify({
            'message': 'Audio file processed successfully',
            'recordingId': audio_url,
            'userId': request.form.get('userId')
        })

    except Exception as e:
        import traceback
        error_message = traceback.format_exc()
        return jsonify({'message': f'Error: {str(e)}', 'details': error_message}), 500

if __name__ == '__main__':
    app.run(debug=True)
